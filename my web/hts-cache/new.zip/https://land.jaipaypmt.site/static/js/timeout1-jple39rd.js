const t="/static/png/timeout1-2japlo1u.png";export{t};
