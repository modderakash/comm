const n="/static/png/n1-6nvpfw1s.png";export{n};
