const s="/static/png/cg-a7qrc0z4.png",c="/static/png/sb-fqdnupsx.png";export{s as c,c as s};
