const t="/static/png/icon-default-head-c1pth40h.png";export{t as g};
